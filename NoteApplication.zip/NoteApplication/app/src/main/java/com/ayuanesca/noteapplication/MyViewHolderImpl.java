package com.ayuanesca.noteapplication;

import android.view.View;

class MyViewHolderImpl extends NoteAdapter.MyViewHolder {
    public MyViewHolderImpl(View view) {
        super(view);
    }
}
