package com.ayuanesca.noteapplication;

import static org.junit.Assert.*;

public class MainActivityTest {

}